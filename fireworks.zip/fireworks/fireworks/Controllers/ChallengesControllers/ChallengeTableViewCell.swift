//
//  ChallengeTableViewCell.swift
//  fireworks
//
//  Created by Terrence Gillespie on 17/11/19.
//  Copyright © 2019 Terrence Gillespie. All rights reserved.
//

import UIKit

//class ChallengeTableViewCell: UITableViewCell {
//
//    @IBOutlet weak var iconImageView: UIImageView!
//    @IBOutlet weak var challengeTitleLabel: UILabel!
//    @IBOutlet weak var titleLabel: UILabel!
//    @IBOutlet weak var bodyLabel: UILabel!
//
//    override func awakeFromNib() {
//        super.awakeFromNib()
//        // Initialization code
//    }
//
//    override func setSelected(_ selected: Bool, animated: Bool) {
//        super.setSelected(selected, animated: animated)
//
//        // Configure the view for the selected state
//    }
//
//}
