//
//  StatisticsUIView.swift
//  fireworks
//
//  Created by Luca Vespoli on 22/11/2019.
//  Copyright © 2019 Terrence Gillespie. All rights reserved.
//

import SwiftUI

struct StatisticsUIView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello World!"/*@END_MENU_TOKEN@*/)
    }
}

struct StatisticsUIView_Previews: PreviewProvider {
    static var previews: some View {
        StatisticsUIView()
    }
}
