//
//  StatisticViewController.swift
//  fireworks
//
//  Created by Luca Vespoli on 22/11/2019.
//  Copyright © 2019 Terrence Gillespie. All rights reserved.
//

import UIKit

class StatisticViewController: UIViewController {

    @IBOutlet weak var basicBarChart: UIView!
    
    private let numEntry = 20
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
